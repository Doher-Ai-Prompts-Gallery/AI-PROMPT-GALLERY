DOHER AI GALLERY - README

IMPORTANT:
DO NOT open index.html directly using file://

Instead run:
npx serve .
or:
python -m http.server 3000

Then open:
http://localhost:3000/

PROJECT PURPOSE:
This is an Image Prompt Gallery website.

USER PANEL:
- Show published images.
- Search and Category filters.
- Dynamic placeholder replacement logic.

ADMIN PANEL:
- Firebase Auth Login.
- Category & Prompt management.
- Image uploads to Firebase Storage.
